# serverless-aws-lambda
Learning of AWS lambda and serverless approach
